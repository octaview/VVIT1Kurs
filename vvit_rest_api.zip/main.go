package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"

	_ "vvit/docs"

	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
)

// @title           Wikipedia Summary API
// @version         1.0
// @description     Простой API для получения сводок страниц из Википедии.
// @host            localhost:8080
// @BasePath        /


type SearchRequest struct {
	Query  string   `json:"query" binding:"required"`
	Titles []string `json:"titles,omitempty"`
	Limit  int      `json:"limit,omitempty"`
}

type PageSummary struct {
	Title       string `json:"title"`
	Description string `json:"description"`
	Extract     string `json:"extract"`
}

type ErrorResponse struct {
	Error string `json:"error"`
}

func getWikipediaSummary(title string) (PageSummary, error) {
	url := fmt.Sprintf("https://ru.wikipedia.org/api/rest_v1/page/summary/%s", title)
	resp, err := http.Get(url)
	if err != nil {
		return PageSummary{}, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return PageSummary{}, fmt.Errorf("Wikipedia API error: %s", resp.Status)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return PageSummary{}, err
	}

	var result struct {
		Title       string `json:"title"`
		Description string `json:"description"`
		Extract     string `json:"extract"`
	}

	if err := json.Unmarshal(body, &result); err != nil {
		return PageSummary{}, err
	}

	return PageSummary{
		Title:       result.Title,
		Description: result.Description,
		Extract:     result.Extract,
	}, nil
}

// @Summary      Получить сводку страницы
// @Description  Возвращает заголовок, описание и выдержку статьи Википедии по заголовку.
// @Tags         page
// @Param        title   path      string  true  "Title of the page"
// @Success      200     {object}  PageSummary
// @Failure      404     {object}  ErrorResponse
// @Router       /page/{title} [get]
func getPageHandler(c *gin.Context) {
	title := c.Param("title")
	summary, err := getWikipediaSummary(title)
	if err != nil {
		c.JSON(http.StatusNotFound, ErrorResponse{Error: err.Error()})
		return
	}
	c.JSON(http.StatusOK, summary)
}

// @Summary      Поиск страниц
// @Description  Ищет список заголовков по запросу.
// @Tags         search
// @Param        q       query     string  true   "Search query"
// @Param        limit   query     int     false  "Max number of results"  default(5)
// @Success      200     {array}   string
// @Failure      400     {object}  ErrorResponse
// @Router       /search [get]
func searchHandler(c *gin.Context) {
	query := c.Query("q")
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "5"))

	if query == "" {
		c.JSON(http.StatusBadRequest, ErrorResponse{Error: "query parameter 'q' is required"})
		return
	}

	url := fmt.Sprintf("https://ru.wikipedia.org/w/api.php?action=opensearch&search=%s&limit=%d&namespace=0&format=json", query, limit)
	resp, err := http.Get(url)
	if err != nil {
		c.JSON(http.StatusInternalServerError, ErrorResponse{Error: err.Error()})
		return
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		c.JSON(http.StatusInternalServerError, ErrorResponse{Error: err.Error()})
		return
	}

	var result []interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		c.JSON(http.StatusInternalServerError, ErrorResponse{Error: err.Error()})
		return
	}

	c.JSON(http.StatusOK, result)
}

// @Summary      Информация по нескольким страницам
// @Description  Принимает JSON с titles и возвращает массив PageSummary.
// @Tags         pages
// @Accept       json
// @Produce      json
// @Param        request body      SearchRequest  true  "SearchRequest"
// @Success      200     {object}  map[string]interface{}
// @Failure      400     {object}  ErrorResponse
// @Router       /pages [post]
func pagesHandler(c *gin.Context) {
	var request SearchRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{Error: err.Error()})
		return
	}

	if len(request.Titles) == 0 && request.Query == "" {
		c.JSON(http.StatusBadRequest, ErrorResponse{Error: "query or titles must be provided"})
		return
	}

	var results []PageSummary
	for _, title := range request.Titles {
		summary, err := getWikipediaSummary(title)
		if err == nil {
			results = append(results, summary)
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"results": results,
		"count":   len(results),
	})
}

func main() {
	r := gin.Default()

	r.GET("/page/:title", getPageHandler)
	r.GET("/search", searchHandler)
	r.POST("/pages", pagesHandler)

	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

	r.Run(":8080")
}